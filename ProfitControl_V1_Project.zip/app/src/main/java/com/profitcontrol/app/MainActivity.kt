package com.profitcontrol.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

private enum class Status { HEALTHY, THIN, LOSS }
private data class Input(
    val price: BigDecimal,
    val cogs: BigDecimal,
    val packaging: BigDecimal,
    val feePct: BigDecimal,
    val fixedFee: BigDecimal,
    val voucher: BigDecimal,
    val affiliatePct: BigDecimal,
    val ads: BigDecimal,
    val other: BigDecimal,
    val units: Int = 1
)
private data class Result(
    val profit: BigDecimal,
    val totalProfit: BigDecimal,
    val margin: BigDecimal,
    val beforeAds: BigDecimal,
    val fee: BigDecimal,
    val affiliate: BigDecimal,
    val totalCost: BigDecimal,
    val roas: BigDecimal?,
    val status: Status
)
private data class Product(
    val id: Long,
    val name: String,
    val input: Input,
    val result: Result,
    val updated: Long
)

private fun bd(s: String) = s.replace(".", "").replace(",", ".").toBigDecimalOrNull() ?: BigDecimal.ZERO
private fun money(v: BigDecimal): String {
    val nf = NumberFormat.getNumberInstance(Locale("id","ID"))
    nf.maximumFractionDigits = 0
    return "Rp" + nf.format(v.setScale(0, RoundingMode.HALF_UP))
}
private fun pct(v: BigDecimal) = v.setScale(2, RoundingMode.HALF_UP).toPlainString() + "%"
private fun calc(i: Input, target: BigDecimal = BigDecimal("20")): Result {
    val p=i.price.max(BigDecimal.ZERO); val c=i.cogs.max(BigDecimal.ZERO)
    val pack=i.packaging.max(BigDecimal.ZERO); val fixed=i.fixedFee.max(BigDecimal.ZERO)
    val voucher=i.voucher.max(BigDecimal.ZERO); val ads=i.ads.max(BigDecimal.ZERO); val other=i.other.max(BigDecimal.ZERO)
    val fee=p*i.feePct/BigDecimal("100"); val aff=p*i.affiliatePct/BigDecimal("100")
    val nonAds=c+pack+fixed+voucher+other+fee+aff
    val total=nonAds+ads; val profit=p-total
    val margin=if(p>BigDecimal.ZERO) profit/p*BigDecimal("100") else BigDecimal.ZERO
    val status=when { profit<=BigDecimal.ZERO -> Status.LOSS; margin>=target -> Status.HEALTHY; else -> Status.THIN }
    val roas=if(p>BigDecimal.ZERO && p-nonAds>BigDecimal.ZERO) p/(p-nonAds) else null
    return Result(profit, profit*i.units, margin, p-nonAds, fee, aff, total, roas, status)
}
private class Store(context: Context) {
    private val sp=context.getSharedPreferences("profit_control", Context.MODE_PRIVATE)
    var targetMargin by mutableStateOf(BigDecimal(sp.getString("targetMargin","20") ?: "20")); private set
    fun saveTarget(v: BigDecimal){ targetMargin=v; sp.edit().putString("targetMargin",v.toPlainString()).apply() }
    fun load(): MutableList<Product> {
        val arr=JSONArray(sp.getString("products","[]") ?: "[]"); val out=mutableListOf<Product>()
        for(n in 0 until arr.length()){ val o=arr.getJSONObject(n)
            val i=Input(bd(o.getString("price")),bd(o.getString("cogs")),bd(o.getString("pack")),bd(o.getString("fee")),
                bd(o.getString("fixed")),bd(o.getString("voucher")),bd(o.getString("aff")),bd(o.getString("ads")),bd(o.getString("other")),o.optInt("units",1))
            out.add(Product(o.getLong("id"),o.getString("name"),i,calc(i,targetMargin),o.optLong("updated")))
        }; return out
    }
    fun save(list: List<Product>){
        val arr=JSONArray(); list.forEach{p-> val o=JSONObject()
            o.put("id",p.id);o.put("name",p.name);o.put("price",p.input.price.toPlainString());o.put("cogs",p.input.cogs.toPlainString())
            o.put("pack",p.input.packaging.toPlainString());o.put("fee",p.input.feePct.toPlainString());o.put("fixed",p.input.fixedFee.toPlainString())
            o.put("voucher",p.input.voucher.toPlainString());o.put("aff",p.input.affiliatePct.toPlainString());o.put("ads",p.input.ads.toPlainString())
            o.put("other",p.input.other.toPlainString());o.put("units",p.input.units);o.put("updated",p.updated);arr.put(o)}
        sp.edit().putString("products",arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProfitControlApp(applicationContext) }
    }
}

@Composable
private fun ProfitControlApp(context: Context) {
    val store=remember{Store(context)}
    var tab by remember{mutableStateOf(0)}
    var products by remember{mutableStateOf(store.load())}
    MaterialTheme {
        Scaffold(bottomBar={
            NavigationBar {
                listOf("Home","Hitung","Simulasi","ROAS","Produk","Setelan").forEachIndexed{idx,label->
                    NavigationBarItem(selected=tab==idx,onClick={tab=idx},
                        icon={Icon(when(idx){0->Icons.Default.Home;1->Icons.Default.Calculate;2->Icons.Default.CompareArrows;3->Icons.Default.ShowChart;4->Icons.Default.Inventory2;else->Icons.Default.Settings},"")},
                        label={Text(label)})
                }
            }
        }){pad->
            Box(Modifier.padding(pad).fillMaxSize()){
                when(tab){
                    0->Dashboard(products, onCalc={tab=1})
                    1->ProfitCheck(store.targetMargin, onSave={name,input->val r=calc(input,store.targetMargin); val p=Product(System.currentTimeMillis(),name,input,r,System.currentTimeMillis()); products=(products+p);store.save(products);tab=4})
                    2->Simulator(store.targetMargin)
                    3->BepRoas()
                    4->Products(products, onDelete={p->products=products.filterNot{it.id==p.id};store.save(products)})
                    5->Settings(store.targetMargin,onSave={store.saveTarget(it)})
                }
            }
        }
    }
}

@Composable private fun Dashboard(products: List<Product>, onCalc:()->Unit){
    val total=products.sumOf{it.result.totalProfit}; val best=products.maxByOrNull{it.result.profit}
    LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{Text("PROFIT CONTROL",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Omzet besar belum tentu untung.",style=MaterialTheme.typography.bodyLarge)}
        item{Card{Column(Modifier.padding(18.dp)){Text("Profit tersimpan");Text(money(total),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}}}
        item{Card{Column(Modifier.padding(18.dp)){Text("Produk tersimpan: ${products.size}");Text("Produk profit tertinggi: ${best?.name ?: "-"}")}}}
        item{Button(onClick=onCalc,modifier=Modifier.fillMaxWidth()){Text("+ Hitung Profit")}}
    }
}

@Composable private fun ProfitCheck(target:BigDecimal,onSave:(String,Input)->Unit){
    var name by remember{mutableStateOf("")}; var price by remember{mutableStateOf("100000")}; var cogs by remember{mutableStateOf("50000")}
    var pack by remember{mutableStateOf("2000")}; var fee by remember{mutableStateOf("8")}; var fixed by remember{mutableStateOf("0")}
    var voucher by remember{mutableStateOf("0")}; var aff by remember{mutableStateOf("10")}; var ads by remember{mutableStateOf("0")}; var other by remember{mutableStateOf("0")}
    val input=Input(bd(price),bd(cogs),bd(pack),bd(fee),bd(fixed),bd(voucher),bd(aff),bd(ads),bd(other))
    val r=calc(input,target)
    FormScreen("CEK PROFIT"){
        Field("Nama Produk",name){name=it}; Field("Harga Jual",price){price=it}; Field("HPP",cogs){cogs=it}; Field("Packaging",pack){pack=it}
        Field("Fee Marketplace %",fee){fee=it} Field("Fee Tetap",fixed){fixed=it}; Field("Voucher/Diskon",voucher){voucher=it}
        Field("Affiliate %",aff){aff=it}; Field("Iklan / Order",ads){ads=it}; Field("Biaya Lain / Order",other){other=it}
        ResultCard(r)
        Button(onClick={onSave(if(name.isBlank())"Produk ${System.currentTimeMillis()%10000}" else name,input)},modifier=Modifier.fillMaxWidth()){Text("Simpan Produk")}
    }
}

@Composable private fun Simulator(target:BigDecimal){
    var price by remember{mutableStateOf("100000")}; var cogs by remember{mutableStateOf("50000")}; var fee by remember{mutableStateOf("8")}; var aff by remember{mutableStateOf("10")}; var ads by remember{mutableStateOf("10000")}
    val i=Input(bd(price),bd(cogs),BigDecimal.ZERO,bd(fee),BigDecimal.ZERO,BigDecimal.ZERO,bd(aff),bd(ads),BigDecimal.ZERO); val r=calc(i,target)
    FormScreen("SIMULATOR"){Field("Harga Jual",price){price=it};Field("HPP",cogs){cogs=it};Field("Fee Marketplace %",fee){fee=it};Field("Affiliate %",aff){aff=it};Field("Iklan / Order",ads){ads=it};ResultCard(r)}
}
@Composable private fun BepRoas(){
    var price by remember{mutableStateOf("100000")};var cogs by remember{mutableStateOf("50000")};var fee by remember{mutableStateOf("8")};var aff by remember{mutableStateOf("10")}
    val r=calc(Input(bd(price),bd(cogs),BigDecimal.ZERO,bd(fee),BigDecimal.ZERO,BigDecimal.ZERO,bd(aff),BigDecimal.ZERO,BigDecimal.ZERO))
    FormScreen("BEP ROAS"){Field("Harga Jual",price){price=it};Field("HPP",cogs){cogs=it};Field("Fee Marketplace %",fee){fee=it};Field("Affiliate %",aff){aff=it}
        Card{Column(Modifier.padding(18.dp)){Text("Profit sebelum iklan");Text(money(r.beforeAds),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(r.roas?.let{"BEP ROAS: ${it.setScale(2,RoundingMode.HALF_UP)}x"}?:"BEP ROAS tidak valid karena profit sebelum iklan ≤ 0")}}
    }
}
@Composable private fun Products(products:List<Product>,onDelete:(Product)->Unit){
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("PRODUK",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)}
        items(products){p->Card{Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("Profit: ${money(p.result.profit)} • Margin: ${pct(p.result.margin)}");Text(when(p.result.status){Status.HEALTHY->"🟢 PROFIT SEHAT";Status.THIN->"🟡 PROFIT TIPIS";Status.LOSS->"🔴 BONCOS"})}
            IconButton(onClick={onDelete(p)}){Icon(Icons.Default.Delete,"Hapus")}
        }}}
    }
}
@Composable private fun Settings(target:BigDecimal,onSave:(BigDecimal)->Unit){
    var value by remember{mutableStateOf(target.toPlainString())}
    FormScreen("PENGATURAN"){Field("Target Margin Sehat %",value){value=it};Button(onClick={onSave(bd(value))},modifier=Modifier.fillMaxWidth()){Text("Simpan Target Margin")};Text("Semua data disimpan lokal di perangkat. Tidak memakai login atau server.")}
}
@Composable private fun FormScreen(title:String,content:@Composable ColumnScope.()->Unit){LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),content=content)}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit={}){
    OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
}
@Composable private fun ResultCard(r:Result){
    Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text("HASIL",fontWeight=FontWeight.Bold);Text("Profit / Order: ${money(r.profit)}",fontWeight=FontWeight.Bold);Text("Margin: ${pct(r.margin)}");Text("Status: ${when(r.status){Status.HEALTHY->"🟢 PROFIT SEHAT";Status.THIN->"🟡 PROFIT TIPIS";Status.LOSS->"🔴 BONCOS"}}");Text("Total biaya / order: ${money(r.totalCost)}")}}
}
