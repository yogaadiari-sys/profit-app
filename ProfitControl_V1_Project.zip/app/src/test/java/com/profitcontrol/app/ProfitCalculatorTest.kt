package com.profitcontrol.app
import org.junit.Test
import java.math.BigDecimal
import org.junit.Assert.assertEquals
class ProfitCalculatorTest {
 @Test fun standard() {
   val r=calc(Input(BigDecimal("100000"),BigDecimal("40000"),BigDecimal("2000"),BigDecimal("8"),BigDecimal.ZERO,BigDecimal("5000"),BigDecimal("10"),BigDecimal("8000"),BigDecimal.ZERO),BigDecimal("20"))
   assertEquals(0,BigDecimal("27000").compareTo(r.profit))
   assertEquals(Status.HEALTHY,r.status)
 }
}
