# Profit Control V1

Offline Android app concept based on the approved Profit Control V1 specification.

## Current build target
- Android application
- Kotlin + Jetpack Compose
- No login
- No backend/server
- Local persistence
- Profit check
- Simulator
- BEP ROAS
- Product list
- Target margin setting

## Build
The included GitHub Actions workflow can build a debug APK on GitHub's Android runner.

If building locally, use JDK 17 and Gradle 8.9 with Android SDK Platform 35 / Build Tools 35.0.0.

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This project has been reconstructed as a clean, simplified implementation of the V1 functional requirements. It is not evidence that Gemini's original PDF source itself compiles.
